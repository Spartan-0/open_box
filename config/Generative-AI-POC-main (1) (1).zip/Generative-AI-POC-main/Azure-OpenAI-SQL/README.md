# Azure Function app that uses GPT to convert a user question in a SQL Query.

The generated SQL query is then executed against an ETQ Safety database view
and results are returned to the calling client in JSON format.