from dotenv import load_dotenv
import os
import openai
import logging
load_dotenv()
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
os.environ['openai_api_key'] =  OPENAI_API_KEY
openai.api_type = "azure"

openai.api_base = "https://testingchatgenai.openai.azure.com/"
openai.api_version = "2023-07-01-preview"
openai.api_key = os.getenv("OPENAI_API_KEY")

# gpt-35-turbo
# gpt-35-turbo-16k
# gpt-4
# gpt-4-32k

def get_completion_from_messages(system_message, user_message, model="gpt-35-turbo", temperature=0, max_tokens=500) -> str:

    messages = [
        {'role': 'system', 'content': system_message},
        {'role': 'user', 'content': f"{user_message}"}
    ]

    try:
        response = openai.ChatCompletion.create(engine=model, api_version="2023-07-01-preview", # pass api_version directly here to avoid 404 error
                messages=messages, temperature=temperature, max_tokens=max_tokens)

        return response.choices[0].message["content"]    
    except Exception as e:
        logging.info(f"Error occurred trying to run openai.ChatCompletion.create(): {e}")
        return None