from dotenv import load_dotenv
import pandas as pd
import os
import openai
import logging
load_dotenv()
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
os.environ['openai_api_key'] =  OPENAI_API_KEY
openai.api_type = "azure"

openai.api_base = "https://testingchatgenai.openai.azure.com/"
openai.api_version = "2023-07-01-preview"
openai.api_key = os.getenv("OPENAI_API_KEY")

# gpt-35-turbo
# gpt-35-turbo-16k
# gpt-4
# gpt-4-32k
def dataframe_to_markdown(df):
    try:
        return df.to_markdown()
    except Exception as e:
        print(f"Error in dataframe_to_markdown: {e}")
        return None

def get_openai_completion(user_prompt, df):
    try:
        df_markdown = dataframe_to_markdown(df)
        completion_prompt_with_df = f'''
        
        You are an expert Analyst!

        We have already generated the following data for the user question:

        {df_markdown}
        
        Your role:
        
        Refer to user's question and provide a summary based on the provided {df_markdown}. Dive deep into the data, extracting key insights, and Offer actionable recommendations based on your analysis.

        Don't attemp to plot chart or provide python code--just dictate the result in plain english
        
        Do not attempt to plot a chart or provide Python code. Simply describe the result in plain English.

        Helpful Example:
        User: "What are the top 10 divisions?"
        Assistant: "Based on the provided data, the top 10 divisions, in terms of count, are as follows: Division X has the highest count, followed by Division Y, Division Z, and so on. Additional insights include...
        '''

        response = openai.ChatCompletion.create(
            engine='gpt-35-turbo',
            messages=[{"role": "system", 
                   "content": completion_prompt_with_df},
                     {"role": "user", 
                   "content": user_prompt}],
            temperature=0,        
            frequency_penalty=0,
            presence_penalty=0)   
        response = response['choices'][0]["message"]["content"]    
        return response
    except Exception as e:
        print(f"Error in get_openai_completion: {e}")
        return None