# sql_gpt_integration.py

import pandas as pd
from safetychat import sql_db
from safetychat.prompts.prompts import SYSTEM_MESSAGE
from safetychat.azure_openai import get_completion_from_messages
import json
import datetime
from datetime import timedelta
import warnings
import logging
# Prevent warning noise from writing to the console.
warnings.simplefilter(action='ignore', category=DeprecationWarning)
warnings.simplefilter(action='ignore', category=UserWarning)

def query_database(query, conn):
    """ Run SQL query and return results in a dataframe """
    return pd.read_sql_query(query, conn)

def run_etq_query(user_message):
    # Connect to SQL database
    conn = sql_db.create_connection()

    # Get the schema representation for the vw_ETQ_Events_fast SQL database view.
    schemas = sql_db.get_schema_representation()

    if user_message:        
        # Format the system message with the schema
        formatted_system_message = SYSTEM_MESSAGE.format(schema=schemas['vw_ETQ_Events_fast'])
        
        # Use the configured generative AI model to translate the user's question into a well-formed SQL query.
        response = get_completion_from_messages(formatted_system_message, user_message)
        
        # Get the JSON formatted SQL statement generated in the prior step.
        json_response = json.loads(response)
        query = json_response['query']    
        logging.info(f'formated query:  {query}' )
        try:    
            # Run the SQL query against the configured database.
            sql_results = query_database(query, conn)
            
            # Return the SQL query results.
            return sql_results

        except Exception as e:
            print(f"Exception in sql_gpt_integration.run_etq_query: {e}")
