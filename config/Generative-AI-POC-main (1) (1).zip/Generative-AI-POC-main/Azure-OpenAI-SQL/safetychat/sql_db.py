# sql_db.py
from dotenv import load_dotenv
import pymssql
import random
from datetime import date, timedelta
from tqdm import tqdm
import pandas as pd
import os
import logging
load_dotenv()
DATABASE_SERVER = os.environ.get("DATABASE_SERVER")
DATABASE_NAME = os.environ.get("DATABASE_NAME")
PASSWORD = os.environ.get("PASSWORD")
USER_NAME = os.environ.get("USER_NAME")

def create_connection():
    """ Connect to a Microsoft SQL Server database """
    conn = None;
    try:    
        conn = pymssql.connect(
        server=DATABASE_SERVER,
        user=USER_NAME ,
        password=PASSWORD,
        database=DATABASE_NAME)

    except pymssql.Error as e:
        print(f"Error connecting to the database: {e}")
        logging.info(f"Error connecting to the database: {e}")
        exit()
    return conn

def create_table(conn, create_table_sql):
    """ We will not be creating tables in this application """
    try:
        create_table_sql = ''        
    except Exception as e:
        print(e)

def insert_data(conn, table_name, data_dict):
    # We won't be doing any inserts on this phase of the project.    
    return -1

def query_database(query):
    """ Run SQL query and return results in a dataframe """
    conn = create_connection()
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

def get_schema_for_vw_ETQ_Events_fast():
    text = 'TEXT'
    integer = 'INTEGER'
    date = 'DATE'
    datetime = 'DATETIME'
    time = 'TIME'

    # vw_ETQ_Events_fast columns:
    # [Division], [INCIDENT_ID], [EtqNumber], [EventDate], [Airline], [Flight], [Tail], [Risk], [ReportType], [IrropType],
    # [Cause], [CauseOther], [Subject], [Description], [Origin], [Destination], [Location], [WSRDate], [OPLEOI], [AnalystNotes]
    # [RiskNotes], [CreatedDate], [Likelihood], [Severity], [ErrStation], [DiscStation], [EventLevel], [DAGSRB], [InvestReq], [Time]

    column_details = {}
    column_details['Division'] = text
    column_details['INCIDENT_ID'] = integer
    column_details['EtqNumber'] = integer
    column_details['EventDate'] = date
    column_details['Airline'] = text
    column_details['Flight'] = text
    column_details['Tail'] = text
    column_details['Risk'] = text
    column_details['ReportType'] = text
    column_details['IrropType'] = text
    column_details['Cause'] = text
    column_details['CauseOther'] = text
    column_details['Subject'] = text
    column_details['Description'] = text
    column_details['Origin'] = text
    column_details['Destination'] = text
    column_details['Location'] = text
    column_details['WSRDate'] = datetime
    column_details['OPLEOI'] = integer
    column_details['AnalystNotes'] = text
    column_details['RiskNotes'] = text
    column_details['CreatedDate'] = date
    column_details['Likelihood'] = text
    column_details['Severity'] = text
    column_details['ErrStation'] = text
    column_details['DiscStation'] = text
    column_details['EventLevel'] = text
    column_details['DAGSRB'] = text
    column_details['InvestReq'] = text
    column_details['Time'] = time

    return column_details

def get_schema_representation():
    db_schema = {}
    view_name = 'vw_ETQ_Events_fast'
    db_schema[view_name] = get_schema_for_vw_ETQ_Events_fast()    
    return db_schema

if __name__ == "__main__":    
    # Getting the schema representation
    print(get_schema_representation())