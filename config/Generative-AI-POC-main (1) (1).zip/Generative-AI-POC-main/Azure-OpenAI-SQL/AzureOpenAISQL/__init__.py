import azure.functions as func
import logging
from safetychat import sql_gpt_integration, etq_agent
from plot_status import status
import pandas as pd
import json

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info(' ')
    logging.info('Python HTTP trigger function is processing a request.')    
    default_response_message = 'The generative AI had a problem processing your request. Please try again with different wording to help it understand better.'
    human_friendly_error_message = 'The generative AI had a problem processing your request. Please try again with different wording to help it understand better.'
    req_body = req.get_json()
    try:
        # parse       
        user_prompt = req_body.get("user_prompt")       
        user_id = req_body.get("user_id")
        session_id = req_body.get("session_id")
        timestamp = req_body.get("timestamp")        

        if None in [user_id,user_prompt, session_id, timestamp]:
            return func.HttpResponse(
                "Missing parameters in request body",
                status_code=400
            )
  
    except Exception as e:
        return func.HttpResponse(
            "An error occurred: {}".format(e),
            status_code=500
        )

    if user_prompt:
        try:
            # Always prepend the user_prompt with a single blank character to with tokenization.
            user_prompt_with_leading_blank_space = ' ' + user_prompt

            # Convert the user's question into a SQL statement, run the query, and return the results.
            results_dataframe = sql_gpt_integration.run_etq_query(user_prompt_with_leading_blank_space)
            
            if type(results_dataframe) is pd.DataFrame:
                results_dataframe.fillna("NUll",inplace=True)
                results_json = results_dataframe.to_json(orient='records')                
                response_json_results ={
                   "user_id": user_id,
                   "session_id": session_id,                    
                   "user_prompt": user_prompt,
                   "timestamp": timestamp,
                   "answer":  etq_agent.get_openai_completion(user_prompt,results_dataframe),
                   "plot_status": status.detail_data(user_prompt),
                   "data": eval(results_json) 
                    }
                          
                return func.HttpResponse(json.dumps(response_json_results), mimetype="application/json", status_code=200)        
            else:
                results_json = MessageAsJSON(default_response_message)
            return func.HttpResponse(results_json, status_code=200)   
        except Exception as e:
            results_json = MessageAsJSON(human_friendly_error_message)
            return func.HttpResponse(results_json, status_code=422)
    else:        
        results_json = MessageAsJSON(default_response_message)
        return func.HttpResponse(results_json, status_code=200)

def MessageAsJSON(msg):    
    # Make the string message into a dictionary.
    message_dict = {"response": msg}

    # Convert the dictionary to a JSON string
    message_json = json.dumps(message_dict)

    return message_json