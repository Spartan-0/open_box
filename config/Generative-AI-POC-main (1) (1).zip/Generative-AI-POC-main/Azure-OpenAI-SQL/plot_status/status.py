from dotenv import load_dotenv
import os
import openai
import logging
import json

load_dotenv()
OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
os.environ['openai_api_key'] = OPENAI_API_KEY
openai.api_type = "azure"

openai.api_base = "https://testingchatgenai.openai.azure.com/"
openai.api_version = "2023-07-01-preview"
openai.api_key = os.getenv("OPENAI_API_KEY")

def detail_data(question):   
    plot_prompt = '''Determine if the given question implies a desire for a plot type is bar, line or na.
    Helpful examples:
    
    User: "plot top 10 error stations"
    Assistant: {"plot": "yes","type":"bar"}
       
    User: "top 10 error stations"
    Assistant: {"plot": "no","type":"na"}
    
    User:  'are there any anaomolos in the data?'
    Assistant: {"plot": "no","type":"na"}
        
    User: "show me the trends of incident ids counts"
    Assistant: {"plot": "yes","type":"line"}
    '''       

    try:
        response = openai.ChatCompletion.create(
            engine='gpt-35-turbo',
            messages = [
                {"role":"system", "content":f"You are an AI assistant that answers query related to airlines safety.{plot_prompt}"},
                {"role":"user", "content": question  },
            ],
            temperature=0,
            max_tokens=100,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0
        )     
        response = response.choices[0]['message'].content.strip()   
        data = json.loads(response)
        return data
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return {"error": str(e)}
