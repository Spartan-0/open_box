import os
import logging
import pymssql
import pandas as pd
from dotenv import load_dotenv
import psycopg2

load_dotenv()
DATABASE_SERVER = os.getenv("DATABASE_SERVER")
DATABASE_NAME = os.getenv("DATABASE_NAME")
PASSWORD = os.getenv("PASSWORD")
USER_NAME = os.getenv("USER_NAME")

PG_DATABASE=os.getenv("PG_DATABASE")
PG_USER=os.getenv("PG_USER")
PG_PASSWORD=os.getenv("PG_PASSWORD")
PG_HOST=os.getenv("PG_HOST")
PG_PORT=os.getenv("PG_PORT")

def create_connection():
    """Connect to a Microsoft SQL Server database."""
    try:    
        return pymssql.connect(
            server=DATABASE_SERVER,
            user=USER_NAME,
            password=PASSWORD,
            database=DATABASE_NAME
        )
    except pymssql.Error as e:
        logging.error(f"Error connecting to the database: {e}")
        exit()
def create_pg_connection():
    """Connect to a PostgreSQL database."""
    try:
        conn = psycopg2.connect(
            host=PG_HOST,
            user=PG_USER,
            password=PG_PASSWORD,
            database=PG_DATABASE
        )
        return conn
    except psycopg2.Error as e:
        logging.error(f"Error connecting to the database: {e}")
        exit()
def query_database(query):
    """Run SQL query and return results in a dataframe."""
    conn = create_pg_connection()
    df = pd.read_sql_query(query, conn)
    conn.close()
    return df

def get_schema_for_vw_ETQ_Events_fast():
    """Return schema for vw_ETQ_Events_fast."""
    TEXT, INTEGER, DATE, DATETIME, TIME = 'TEXT', 'INTEGER', 'DATE', 'DATETIME', 'TIME'
    
    return {
        'Division': TEXT,
        'INCIDENT_ID': INTEGER,
        'EtqNumber': INTEGER,
        'EventDate': DATE,
        'Airline': TEXT,
        'Flight': TEXT,
        'Tail': TEXT,
        'Risk': TEXT,
        'ReportType': TEXT,
        'IrropType': TEXT,
        'Cause': TEXT,
        'CauseOther': TEXT,
        'Subject': TEXT,
        'Description': TEXT,
        'Origin': TEXT,
        'Destination': TEXT,
        'Location': TEXT,
        'WSRDate': DATETIME,
        'OPLEOI': INTEGER,
        'AnalystNotes': TEXT,
        'RiskNotes': TEXT,
        'CreatedDate': DATE,
        'Likelihood': TEXT,
        'Severity': TEXT,
        'ErrStation': TEXT,
        'DiscStation': TEXT,
        'EventLevel': TEXT,
        'DAGSRB': TEXT,
        'InvestReq': TEXT,
        'Time': TIME
    }

def get_schema_representation():
    """Return database schema representation."""
    return {'vw_ETQ_Events_fast': get_schema_for_vw_ETQ_Events_fast()}
