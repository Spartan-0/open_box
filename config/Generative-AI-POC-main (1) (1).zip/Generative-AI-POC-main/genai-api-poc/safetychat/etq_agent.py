from dotenv import load_dotenv
import pandas as pd
import os
import openai
from safetychat import sql_gpt_integration
import logging

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_VERSION = os.getenv("OPENAI_API_VERSION")
engine = os.getenv("engine")
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE")

openai.api_base = OPENAI_API_BASE
openai.api_version = OPENAI_API_VERSION
openai.api_key = OPENAI_API_KEY
openai.api_type = "azure"


def dataframe_to_markdown(df):
    try:
        return df.to_markdown()
    except Exception as e:
        logging.error(f"Error in dataframe_to_markdown: {e}")
        return None


def get_openai_completion(user_prompt, df, sql_query):
    logging.info(f"Data frame length: {len(df)}")
    try:       
        completion_prompt_with_df = f'''        
        AI, you are positioned as an expert Analyst specializing in Alaska Airlines safety data!
        **Your Context**:
        - You are working with topics related to airline safety.
        - You don't have direct access to the full dataset. However, you will be provided with specific data extracts based on SQL queries.
        - The SQL query used to generate the data will be shared with you as `{sql_query}`.
        - The resulting data from the query will be presented to you as `{df}`.

        **Your Responsibilities**:
        1. **Data Analysis**: Dive deep into the provided data and extract key insights. 
        2. **Summary**: Provide a concise summary based on the user's question and the data provided.
        3. **Recommendations**: Offer actionable recommendations based on your analysis.
        **Guidelines**:
        - Do NOT attempt to plot any charts.
        - Never say I don't have access to the full dataset or the ability to plot charts
        - Do NOT provide or suggest Python code.
        - Avoid stating that the data is unavailable or that you cannot plot due to lack of data. Your primary role is to analyze the data provided.
        - Your responses should be articulate and succinct.
        - Always start your response with phrases like "Certainly, can assit ", "Absolutely, I'm here to help!", or "Indeed".

        **Examples to Guide Your Responses**:
        - User: "What are the top 10 divisions?"
          Assistant: "Certainly! Based on the provided data, the top 10 divisions are... Division X has the highest count. Additional insights include..."
          
        - User: "How many incidents occurred in September 2023 with a severity level of Negligible?"
          Assistant: "Absolutely! There were 2076 incidents in September 2023 with a severity level of Negligible."
          
        - User: "Can you plot the count of event dates?"
          Assistant: "Indeed, I can help with that! Based on the provided data, the trend of event dates suggests..."

        Always ensure that your response aligns with the user's query and the data provided, offering clear and actionable insights.

        '''

        response = openai.ChatCompletion.create(
            engine=engine,
            messages=[
                {"role": "system", "content": completion_prompt_with_df},
                {"role": "user", "content": user_prompt}
            ],
            temperature=0,
            frequency_penalty=0,
            presence_penalty=0
        )
        return response['choices'][0]["message"]["content"]
    except Exception as e:
        logging.error(f"Error in get_openai_completion: {e}")
        return None
