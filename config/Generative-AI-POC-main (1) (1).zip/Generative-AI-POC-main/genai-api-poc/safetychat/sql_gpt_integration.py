import pandas as pd
import json
import logging
from safetychat import sql_db
from safetychat.prompts.prompts import SYSTEM_MESSAGE
from safetychat.azure_openai import get_completion_from_messages

# Configure logging and suppress specific warnings
logging.basicConfig(level=logging.INFO)
for warning_category in [DeprecationWarning, UserWarning]:
    logging.captureWarnings(True)

def run_etq_query(user_message):
    """Translate user's question into SQL query, execute it, and return results."""
    
    # Return early if no user message is provided
    if not user_message:
        return None, None

    # Connect to SQL database
    conn = sql_db.create_pg_connection()

    # Get the schema representation for the vw_ETQ_Events_fast SQL database view.
    schema = sql_db.get_schema_representation().get('vw_ETQ_Events_fast', {})

    # Format the system message with the schema
    formatted_system_message = SYSTEM_MESSAGE.format(schema=schema)
    
    # Use the configured generative AI model to translate the user's question into a SQL query.
    response = get_completion_from_messages(formatted_system_message, user_message)
    
    # Extract the SQL statement from the AI response
    query = json.loads(response).get('query', '')
    logging.info(f'Formatted query: {query}')

    try:    
        # Run the SQL query against the database and return the results.
        sql_results = pd.read_sql_query(query, conn)
        return sql_results, query

    except Exception as e:
        logging.error(f"Exception in run_etq_query: {e}")
        return None, None
