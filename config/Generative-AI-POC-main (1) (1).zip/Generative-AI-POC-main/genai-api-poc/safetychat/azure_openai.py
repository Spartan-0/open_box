import os
import openai
import logging
from dotenv import load_dotenv

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_VERSION = os.getenv("OPENAI_API_VERSION")
engine = os.getenv("engine")
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE")
openai.api_base = OPENAI_API_BASE
openai.api_version =OPENAI_API_VERSION
openai.api_key = OPENAI_API_KEY
openai.api_type = "azure"

def get_completion_from_messages(system_message, user_message, temperature=0, max_tokens=500) -> str:
    messages = [
        {'role': 'system', 'content': system_message},
        {'role': 'user', 'content': user_message}
    ]

    try:
        response = openai.ChatCompletion.create(
            engine=engine,
            messages=messages,
            temperature=temperature,
            max_tokens=max_tokens
        )
        return response.choices[0].message["content"]
    except Exception as e:
        logging.error(f"Error occurred trying to run openai.ChatCompletion.create(): {e}")
        return None
