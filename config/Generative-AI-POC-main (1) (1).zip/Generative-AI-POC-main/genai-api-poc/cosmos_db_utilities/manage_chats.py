from azure.cosmos import CosmosClient, PartitionKey, exceptions
from dotenv import load_dotenv
import datetime
import os
import logging
load_dotenv()
COSMOS_DB_URL = os.getenv("COSMOS_DB_URL")
COSMOS_DB_KEY = os.getenv("COSMOS_DB_KEY")
COSMOS_DB_DATABASE_NAME = os.getenv("COSMOS_DB_DATABASE_NAME")
COLLECTION_NAME = os.getenv("COLLECTION_NAME")

client = CosmosClient(COSMOS_DB_URL, credential=COSMOS_DB_KEY)
database = client.get_database_client(COSMOS_DB_DATABASE_NAME)
container = database.get_container_client(COLLECTION_NAME)

def create_new_id(payload: dict):
    container.upsert_item(payload)

def upsert_chat_item(payload: dict):
    try:
        existing_document = container.read_item(
            payload["id"],
            payload["user_id"]
        )
       
        existing_chats = existing_document.get("chats", [])
       
        if "chat_title" in payload and not existing_document.get("chat_title"):
            existing_document["chat_title"] = payload["chat_title"]
       
        new_chat = payload["chats"][0]
        existing_chats.append(new_chat)
       
        payload["chats"] = existing_chats
       
        container.upsert_item(existing_document)
       
        return "Success"  
    except Exception as e:        
        error_message = f"Error occurred: {str(e)}"
        return {"error": error_message}
    
def delete_chat_history(payload: dict):
    user_id = payload["user_id"]
    chat_id = payload["id"]
    try:
        container.delete_item(item=chat_id, partition_key=user_id)

        return f"Deleted chat record with id {chat_id} for user_id {user_id}"
    except Exception as e:
        return f"Error deleting chat record with id {chat_id} for user_id {user_id}: {str(e)}"


def get_chat_by_user_id(user_id: str):
    end_date = datetime.datetime.now()
    start_date = end_date - datetime.timedelta(days=30)

    query = f"""
    SELECT c.id, c.user_id, c.chat_title, c.chats
    FROM c
    WHERE c.user_id = '{user_id}'
    AND ARRAY_LENGTH(
        ARRAY(
            SELECT VALUE chat
            FROM chat IN c.chats
            WHERE chat.timestamp >= '{start_date.strftime('%Y-%m-%d %H:%M:%S.%f')}'
            AND chat.timestamp < '{end_date.strftime('%Y-%m-%d %H:%M:%S.%f')}'
        )
    ) > 0
    """

    results = list(container.query_items(query=query, enable_cross_partition_query=True))
    logging.info(query)
    return results

def get_chat_by_id(id: str):
    query = f"""
    SELECT c.id, c.user_id, c.chat_title, c.chats
    FROM c
    WHERE c.id = '{id}'
    """

    results = list(container.query_items(query=query, enable_cross_partition_query=True))    
    return results

def update_chat_title(id: str,user_id:str, chat_title: str):    
    existing_document = container.read_item(item=id, partition_key=user_id)
    
    existing_document["chat_title"] = chat_title
    
    container.upsert_item(existing_document)

    return f"Updated chat title for id {id} to {chat_title}"

def upsert_message_flag(payload: dict):
    try:        
        existing_document = container.read_item(payload["id"], payload["user_id"])
        
        existing_chats = existing_document.get("chats", [])        
       
        message_id_to_update = payload.get("message_id")
        message_flag_to_update = payload.get("message_flag")        
       
        for chat in existing_chats:
            if chat.get("message_id") == message_id_to_update:               
                if message_flag_to_update:
                    chat["message_flag"] = message_flag_to_update
                break
        else:           
            if message_flag_to_update:
                new_chat = {"message_id": message_id_to_update, "message_flag": message_flag_to_update}
                existing_chats.append(new_chat)
              
        existing_document["chats"] = existing_chats        
       
        container.upsert_item(existing_document)
        
        return {"success": "True", "message": "Message flag upserted successfully."}
    
    except Exception as e:
        return {"success": "False", "error_message": str(e)}
        
def upsert_image(payload: dict):
    try:        
        existing_document = container.read_item(payload["id"], payload["user_id"])
        
        existing_chats = existing_document.get("chats", [])        
       
        message_id_to_update = payload.get("message_id")
        image_base64_to_update = payload.get("image_base64")
       
        for chat in existing_chats:
            if chat.get("message_id") == message_id_to_update:               
                if image_base64_to_update:
                    chat["image_base64"] = image_base64_to_update
                break
        else:           
            if image_base64_to_update:
                new_chat = {"message_id": message_id_to_update, "image_base64": image_base64_to_update}
                existing_chats.append(new_chat)
              
        existing_document["chats"] = existing_chats        
       
        container.upsert_item(existing_document)
        
        return {"success": "True", "message": "Image (base64) upserted successfully."}
    
    except Exception as e:
        return {"success": "False", "error_message": str(e)}
