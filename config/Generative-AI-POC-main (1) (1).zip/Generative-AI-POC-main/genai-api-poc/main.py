import os
import json
import uuid
import logging
import pandas as pd
from fastapi import FastAPI, HTTPException
from fastapi.responses import StreamingResponse, JSONResponse
from typing import Optional
import datetime
import base64
from safetychat import sql_gpt_integration, etq_agent
from plot_status import status
from customer_emails import customer_email_response
from cosmos_db_utilities import manage_chats 
from topic_modeling import infer
from safety_manuals import chunks

app = FastAPI(debug=True)
logging.basicConfig(level=logging.INFO)

def process_chat_title(user_prompt):    
    chat_title = eval(status.suggest_chat_title(user_prompt))       
    try:
        chat_title = chat_title["title"]
    except:
        pass
    return chat_title

def process_plot_status(user_prompt, plot_status):
    plot_required = status.detail_data(user_prompt)
    plot_required_ = eval(plot_required)    
    plot_status["plot"] = plot_required_["plot"]
    plot_status["type"] = plot_required_["type"]
    if  plot_status["plot"]=="yes":
        chart_propert = eval(status.suggest_plot_title(user_prompt))
        logging.info( chart_propert)
        plot_status["plot_title"] = chart_propert["plot_title"]
        plot_status["x_axis"] = chart_propert["x_axis"]
        plot_status["y_axis"] = chart_propert["y_axis"]


def error_response(message='The generative AI had a problem processing your request. Please try again with different wording to help it understand better.', status_code=200):
    return json.dumps({"response": message})

@app.post("/create-session-id")
def create_session_id(payload: dict):
    user_id = payload.get("user_id")        
                    
    if None in [user_id]:
        return error_response("Missing parameters in request body", 400)    
    try:
        new_session = {"id": str(uuid.uuid4()),
                   "user_id":base64.b64encode(user_id.encode()).decode(),
                   "chats": [ {"timestamp": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')}
                   ]
                   }
        manage_chats.create_new_id(new_session )
      
        return new_session
    except Exception as e:
        error_message = f"Error occurred: {e}"
        logging.error(error_message)
       
        return {"error": error_message}

@app.post("/safety-bot")
async def get_response(payload: dict):
    try:
        user_prompt = payload.get("user_prompt")
        user_id = payload.get("user_id")
        id = payload.get("id")       
                
        if None in [user_id, user_prompt, id]:
            return error_response("Missing parameters in request body", 400)
            
        cat = infer.topic(user_prompt)
        #logging.info(cat)
        plot_status = {"plot": "no", "type": "na", 
                              "plot_title": "na",
                              "x_axis": "na",
                              "y_axis": "na"}
        if "etq" not in cat:
            chat_title = process_chat_title(user_prompt)
            try:
                
                manuals = {"id": id,
                   "user_id":base64.b64encode(user_id.encode()).decode(),
                   "chat_title": chat_title,
                   "chats": [ {
                            "user_prompt": user_prompt,
                             "answer":chunks.retrieve(user_prompt),
                             "plot_status": plot_status,
                             "message_id": str(uuid.uuid4()),
                             "category":"safety-manuals",
                             "timestamp": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
                             }
                             ]
                   }
                db_status = manage_chats.upsert_chat_item(manuals)
                return {"id": id,
                       "user_id":base64.b64encode(user_id.encode()).decode(),
                       "chat_title": chat_title,
                       "chats": [ {
                                "user_prompt": user_prompt,
                                 "answer":chunks.retrieve(user_prompt),
                                 "plot_status": plot_status,
                                 "message_id": str(uuid.uuid4()),
                                 "category":"safety-manuals",
                                 "timestamp": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
                                 }
                                 ]
                        }
            except Exception as e:
                logging.error(f"Error occurred: {e}")
                return error_response()               
        
        try:
            results_dataframe, query = sql_gpt_integration.run_etq_query(' ' + user_prompt)
            if isinstance(results_dataframe, pd.DataFrame):
                results_dataframe.fillna("NUll", inplace=True)                

                chat_title = process_chat_title(user_prompt)
                answer = etq_agent.get_openai_completion(user_prompt, results_dataframe,query)
                logging.info(answer)
                if answer is None:
                    answer = chat_title

                if  results_dataframe.shape[1] == 2 and  results_dataframe.shape[0] >= 5:
                    process_plot_status(user_prompt, plot_status)

                results_json =  results_dataframe.to_json(orient='records')
                
                response_data = {"id": id,
                "user_id":base64.b64encode(user_id.encode()).decode(),
                "chat_title": chat_title,
                "chats": [ {
                        "user_prompt": user_prompt,                      
                        "answer": answer,
                        "plot_status": plot_status,
                        "data": eval(results_json),
                         "message_id": str(uuid.uuid4()),
                         "category":"etq",
                         "timestamp": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
                         }
                         ]
                }             
                db_status = manage_chats.upsert_chat_item(response_data)                              
                return {"id": id,
                        "user_id":base64.b64encode(user_id.encode()).decode(),
                        "chat_title": chat_title,
                        "chats": [ {
                                "user_prompt": user_prompt,                      
                                "answer": answer,
                                "plot_status": plot_status,
                                "data": eval(results_json),
                                 "message_id": str(uuid.uuid4()),
                                 "category":"etq",
                                 "timestamp": datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')
                                 }
                                 ]
                        }
            else:
                return error_response()
        except Exception as e:
            logging.error(f"Error occurred: {e}")
            return error_response()
             
    except Exception as e:
        logging.error(f"Error occurred: {e}")
        raise HTTPException(status_code=500, detail=str(e))
        
@app.post("/delete-chat-history")
def delete_chat_history(payload: dict): 
    user_id = payload["user_id"]
    chat_id = payload["id"]
    payload_ = {"id": chat_id,
                "user_id":base64.b64encode(user_id.encode()).decode()
                }
    return manage_chats.delete_chat_history(payload_)


@app.get("/search-chat-user-id/{user_id}")
def get_chat_by_user_id(user_id: str):   
    user_id = base64.b64encode(user_id.encode()).decode()
    return manage_chats.get_chat_by_user_id(user_id)
 
@app.get("/search-chat-id/{id}")
def get_chat_by_id(id: str):      
    return manage_chats.get_chat_by_id(id)
    
@app.post("/update-chat-title")
def update_chat_title(payload: dict): 
    id = payload["id"]
    user_id = payload["user_id"]
    user_id = base64.b64encode(user_id.encode()).decode()
    chat_title = payload["chat_title"]
    
    return manage_chats.update_chat_title(id, user_id, chat_title)
    
@app.post("/upsert-message-flag")
def upsert_message_flag(payload: dict):     
    payload["user_id"] = base64.b64encode( payload["user_id"].encode()).decode()  
    
    return manage_chats.upsert_message_flag(payload)
    
@app.post("/email-response")
def email_response(payload: dict):
    logging.info(payload.user_prompt)
    try:
        new_email = payload.user_prompt
        response = customer_email_response.new_email_response(new_email)
        return response
    except Exception as e:
        error_message = f"Error occurred: {e}"
        logging.error(error_message)
       
        return {"error": error_message}

