from dotenv import load_dotenv
import os
import openai
import logging
import json

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_VERSION = os.getenv("OPENAI_API_VERSION")
engine = os.getenv("engine")
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE")
openai.api_base = OPENAI_API_BASE
openai.api_version = OPENAI_API_VERSION
openai.api_key = OPENAI_API_KEY
openai.api_type = "azure"

def openai_api_call(question, system_content):
    try:
        response = openai.ChatCompletion.create(
            engine=engine,
            messages=[
                {"role": "system", "content": system_content},
                {"role": "user", "content": question},
            ],
            temperature=0,
            max_tokens=100,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0
        )
        response_content = response.choices[0]['message'].content.strip()       
                           
        return response_content
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return {"error": str(e)}

def topic(question):
    system_content = """
    You are an expert in Topic Modeling!

    There are three main categories to which topics can be assigned: etq, sms, and aag.
    You must return only one best category, etq, sms or aag!
    Your answer must be in 3 letters!

    1. **etq Category**:
        - **Columns and Sample Values**:
            - Division: AOCS, DG
            - INCIDENT_ID: 84493, 84499, 84504, 84508, 84515
            - EtqNumber: 81319, 81325, 81330, 81334, 81341
            - EventDate: 9/28/2018
            - Airline: AS
            - Flight: 773, 287, 896, 1337
            - Tail: N527AS, N492AS, n626
            - Risk: 1, 0
            - ReportType: AOCS & Station : Damage, AOCS & Station : Other Operational Issue, Dangerous Goods : Other, AOCS & Station : Customer Related Event
            - Subject: Shear pin broke during pushback due to main gear chocks not being removed., Agent hit head on belt door., Shear pin broke due to no bypass pin being installed., Incorrectly filed- should be a DG bag report. Filer was notified, Intoxicated and disruptive passenger removed from flight.
            - Origin: EWR, LAX, hnl, FLL
            - Destination: SAN, SEA, atl, LAX
            - Location: EWR, HNL, LAX, FLL
            - WSRDate: 
            - OPLEOI: 0.0
            - AnalystNotes: 
            - Severity: Negligible, No Safety Implication
            - EventLevel: A, NSI
            - DAGSRB: No
            - InvestReq: No
            - Time: 0:10:00, 2:32:00, 6:29:00, 0:30:00, 0:04:00  
        sample questions:
        Were there any specific routes or destinations that had a higher frequency of events involving Dangerous Goods in 2022? 
        Are there specific tail numbers (Tail) that are associated with a higher number of incidents?
        How do events related to crew scheduling impact flight operations, and what measures can be taken to mitigate them?
        How do events related to Dangerous Goods compare in frequency and severity to other types of events?
        Are there specific flights that have a higher frequency of incidents compared to others?
        Are there specific routes or destinations that experience a higher number of immigration issues? 
        How do airlines address and resolve "Passenger Dissatisfied" incidents?
    2. **sms Category**:
        - This category pertains to Alaska Airlines' Safety Management System. Topics include:
            - Components of Safety Management
            - Safety Management System 
            - Compliance with Legal and Other Requirements
            - Safety Risk Management
            - Aviation Safety Action Programs
            - Revision Record, Coordination and Contror
            - Safety Performance Monitoring and Measurement
            - Aviation Safety Action Programs (ASAP)
            - Operations Performance Leadership (OPL)
            - Employee Reporting and Feedback System
            - Safety Review Boards (SRBs)
            - Safety Policy and Objectives, and more.

    3. **aag Category**:
        - This category covers topics related to Alaska Airlines Safety Manual, including:
            - Corporate Responsibilities
            - Safety Programs
            - Ground Damage and NTSB Reporting
            - Accident Prevention Program
            - Hazard Assessment
            - Mandatory Reporting
            - Code Share Operational Review Program
            - Bloodborne Pathogens Exposure Control Plan
            - Stinson Facility Emergency Action Plan
            - Use of Personal Protective Equipment, and more.

    Your role is to categorize the topic into one of these categories based on the user's query.
    
    **Useful Examples for AI**:
    - If a user asks, "What are the top ten divisions?", your response should be: {{"topic": "etq"}}
    - For the question, "What is the safety policy of Alaska Airlines and Horizon Air?", respond with: {{"topic": "sms"}}
    - If queried, "What is the organizational structure of the Safety Division?", your answer should be: {{"topic": "aag"}}
    """
    return openai_api_call(question, system_content)