from dotenv import load_dotenv
from datetime import datetime
import os
import openai
import logging
import json

current_date = datetime.now()
formatted_date = current_date.strftime("%B %d, %Y")

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_VERSION = os.getenv("OPENAI_API_VERSION")
engine = 'gpt-35-turbo-16k'
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE")
openai.api_base = OPENAI_API_BASE
openai.api_version = OPENAI_API_VERSION
openai.api_key = OPENAI_API_KEY
openai.api_type = "azure"
path = os.path.join(os.getcwd(),"data", "customer_emails.txt")
#docker build --no-cache -t belete12/your_image_name:your_tag .
#docker run -p 8000:80 --env-file .env belete12/your_image_name:your_tag
#uvicorn main:app --host 0.0.0.0 --port 80 --workers 4
#uvicorn main:app --host 0.0.0.0 --port 80 --log-level debug
with open(path, 'r') as file:
    sample_emails = file.read()
    
def openai_api_call(new_email, system_content):
    try:
        response = openai.ChatCompletion.create(
            engine=engine,
            messages=[
                {"role": "system", "content": system_content},
                {"role": "user", "content": new_email},
            ],
            temperature=0,           
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0
        )
        response_content = response.choices[0]['message'].content.strip()       
                
        parsed_json = json.loads(response_content)
        parsed_json['Details']['Response']['Message'] = f"{formatted_date}\n{parsed_json['Details']['Response']['Message']}"
        return  parsed_json
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return {"error": str(e)}

def new_email_response(new_email):
    sample_emails_ = f'''
    You are an AI assistant that answers queries related to Alaska Airlines Customers. You have access to the following resources:
    {sample_emails}
    '''
    system_content =sample_emails_ + """
    Your primary task is to meticulously extract ALL details from the provided text, 
    including but not limited to first name, last name, email addresses, flight details, 
    complaints, and any other relevant inputs. 
    After extracting these details, you must prepare email responses that comprehensively include all these extracted details.
    
    If First or Last Name is not given, 'Recipient' is Sir/Madam
    
    Ensure you address the right person.
    
    Ensure your response is in correctly formatted JSON.
       
    For instance:

    User Query: 
    Seat Complaints

    Email From Guest 
    
    FirstName: Kathleen 
    LastName: Moon 
    Email: katiehaemoon@gmail.com 
    MileagePlan: 338143525 
    HphoneNumber: 9082278332 
    Confirmation: LLYERS 
    FlightNo1: 1071 
    From1: SAN 
    To1: SEA 
    Date1: MAY 23, 2023 
    Complaint: "I purchased seat 9F for about $68 total and the seat I got was broken. The bottom part of the seat seemed to be missing half a cushion so that I could feel the bar of the seat the entire time. This was my first time on Alaska so I had thought it was just an uncomfortable seat but the more I sat the more uncomfortable I was until I felt around and realized the bottom half of the seat was just missing. I also sat on a different seat while deboarding and confirmed it was really just my seat that was broken.",
    
    Expected AI Response:
   {
    "Details": {
        "ComplaintType": "Seat Complaints",
        "Response": {
            "FirstName": "Kathleen",
            "LastName": "Moon",
            "Email": "katiehaemoon@gmail.com",
            "MileagePlan": "338143525",
            "HphoneNumber": "9082278332",
            "Confirmation": "LLYERS",
            "FlightNo1": "1071",
            "From1": "SAN",
            "To1": "SEA",
            "Date1": "MAY 23, 2023",
            "Date": "October 10, 2023",
            "Recipient": "Kathleen",
            "Message": "\n\nDear Kathleen, \nThank you for sharing your concerns regarding your recent flight to Seattle. It's our goal to make sure every trip you have on Alaska goes smoothly. The best way for us to do that is hearing from you. I was discouraged to hear that your seat was broken and the bottom half appeared to be missing compared to other seats. I sincerely apologize for the discomfort you experienced. We appreciate you bringing this to our attention. I assure you I have shared your concerns with our Maintenance and Engineering Department for internal review. As a customer service gesture, we've included a Discount Code at the bottom of this email for future travel on Alaska. To use the code, go to alaskaair.com/planbook and enter it into the discount code field on the right side of the booking form. Your discount is valid for ticketing for one year and is good for travel between any of the +115 destinations operated by Alaska Airlines. This discount is limited to a single reservation and only one discount code can be used per reservation. Complete discount code rules and restrictions can be found online at alaskaair.com. Kathleen Moon, Discount Code ECSR75CPCWC1053841, in the amount of $75 I hope that you will accept my invitation to join us on another flight. I'm confident that we will once again live up to your expectations. Sincerely, Alexi L. Customer Care Representative"
        }
    }
}
    
    """
    return openai_api_call(new_email,  system_content)