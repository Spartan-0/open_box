from dotenv import load_dotenv
import os
import openai
import logging
import json

load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_VERSION = os.getenv("OPENAI_API_VERSION")
engine = os.getenv("engine")
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE")
openai.api_base = OPENAI_API_BASE
openai.api_version = OPENAI_API_VERSION
openai.api_key = OPENAI_API_KEY
openai.api_type = "azure"

def openai_api_call(question, system_content):
    try:
        response = openai.ChatCompletion.create(
            engine=engine,
            messages=[
                {"role": "system", "content": system_content},
                {"role": "user", "content": question},
            ],
            temperature=0,
            max_tokens=100,
            top_p=1,
            frequency_penalty=0,
            presence_penalty=0
        )
        response_content = response.choices[0]['message'].content.strip()  
        logging.info(  response_content)
           
        return response_content
    except Exception as e:
        logging.error(f"An error occurred: {e}")
        return {"error": str(e)}

def detail_data(question):
    system_content = f"""AI, your primary responsibility is to interpret queries related to airline safety and determine the type of plot implied by the user's question.
    Your task is to analyze the user's question and decide:
    1. Whether the user is implying a desire for a plot.
    2. If yes, what type of plot do they likely want: bar, or line
    Here's a clear guideline for your responses:
    1. If the user's query suggests a categorical representation, like "top 10 error stations", the plot type should be "bar".
    2. If the user's query indicates a trend or change over time, like "incident counts over months", the plot type should be "line".
    3. If the user's query doesn't imply any specific plot, the response should be "na".
    **Examples to Guide You**:
    - User: "Plot the top 10 error stations."
      Your Response: {{"plot": "yes", "type": "bar"}}
    - User: "What are the top 10 error stations?"
      Your Response: {{"plot": "no", "type": "na"}}
    - User: "Are there any anomalies in the data?"
      Your Response: {{"plot": "no", "type": "na"}}
    - User: "Show me the trends of incident IDs counts over the years."
      Your Response: {{"plot": "yes", "type": "line"}}
    Always ensure that your response aligns with the user's implied desire for visual representation and the type of data they are referencing.
    Always ensure that your response is correctly JSON formatted.

    """
    return openai_api_call(question, system_content)

def suggest_plot_title(question):
    system_content = f"""AI, your primary role is to assist in generating labels for plots!
    You specialize in creating titles and axis labels for plots, specifically those related to Alaska Airlines' safety data. When given context or a description of a plot, you should provide a suitable title along with labels for both the x-axis and y-axis.
    Your expertise lies in understanding the context and producing relevant and descriptive labels for visual data representations.
    Here's a clear example to guide you:
    When a user asks: "Suggest a title and labels for a plot showing the number of safety incidents over time."
    Your response should be in the following format: 
    {{"plot_title": "Safety Incidents Over Time", "x_axis": "Date (Months)", "y_axis": "Number of Incidents"}}
    
    When a user asks: "show me lists of top 10 divisions"
    Your response should be in the following format: 
    {{"plot_title": " Top 10 divisions", "x_axis": "Divisions", "y_axis": "Count of Divisions"}}
    
    If the user's query doesn't imply any specific plot, the response should be:
    {{"plot_title": "na", "x_axis": "na", "y_axis": "na"}}
    Always ensure that the labels are relevant to the user's prompt and provide clarity to the plot's content.
    """
    return openai_api_call(question, system_content)

def suggest_chat_title(question):
    system_content = f"""AI, you have a specialized role in this system!
    Your primary function is to generate concise chat titles based on the context of the conversation. These titles should succinctly summarize the essence of the chat, and they must be limited to a maximum of seven words.
    The primary theme of the queries you'll encounter is related to Alaska Airlines' safety data. Your expertise lies in distilling complex or lengthy information into short, meaningful titles.
    Here's a clear example to guide you:
    When a user says: "Propose a title to encapsulate our current chat session."
    Your response format should be: {{title": "Alaska Airlines Safety Overview"}}
    Remember, always keep the titles brief and relevant!

    """
    return openai_api_call(question, system_content)
