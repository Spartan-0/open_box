import requests
import os
import logging
from dotenv import load_dotenv
import json
load_dotenv()

OPENAI_API_KEY = os.getenv("OPENAI_API_KEY")
OPENAI_API_VERSION = os.getenv("OPENAI_API_VERSION")
cgs_deployment_id = os.getenv("cgs_deployment_id")
OPENAI_API_BASE = os.getenv("OPENAI_API_BASE")

search_endpoint = os.getenv("search_endpoint")
search_key = os.getenv("search_key")
search_index = os.getenv("search_index")

url = f"{OPENAI_API_BASE}/openai/deployments/{cgs_deployment_id}/extensions/chat/completions?api-version={OPENAI_API_VERSION}"
headers = {
    "Content-Type": "application/json",
    "api-key":OPENAI_API_KEY
}
def retrieve(user_prompt):

    data = {
        "dataSources": [
            {
                "type": "AzureCognitiveSearch",
                "parameters": {
                    "endpoint": search_endpoint,
                    "key": search_key,
                    "indexName": search_index
                }
            }
        ],
        "messages": [
            {
                "role": "system",
                "content": "You are an AI assistant dealing with Safety Manual and Safety Management System \
                        (SMS) Manual of Alaska Airlines, Inc. / Horizon Air (Alaska Air Group). Good luck!"
            },
            {
                "role": "user",
                "content": user_prompt
            }
        ]
    }

    response = requests.post(url, headers=headers, json=data)
    response_json = json.loads(response.text)
    return response_json['choices'][0]['message']['content']