#from dotenv import load_dotenv
from langchain.agents.agent import AgentExecutor
from langchain.agents import ZeroShotAgent, AgentType
from langchain.callbacks.base import BaseCallbackManager
from langchain.vectorstores.azuresearch import AzureSearch
from langchain.text_splitter import CharacterTextSplitter
from langchain.embeddings.openai import OpenAIEmbeddings
from langchain.llms import AzureOpenAI
from langchain.chains import ConversationalRetrievalChain
from langchain.memory import ConversationSummaryBufferMemory
from langchain.memory import ConversationBufferMemory
from langchain.prompts.prompt import PromptTemplate
from langchain.memory.chat_message_histories import RedisChatMessageHistory
from azure.search.documents import SearchClient
from azure.core.credentials import AzureKeyCredential
from langchain.chat_models import ChatOpenAI
from langchain.tools.python.tool import PythonAstREPLTool
from langchain.tools import BaseTool
from langchain.chains.llm import LLMChain
from langchain.llms.base import BaseLLM
from typing import Any, List, Optional
import azure.functions as func
from io import StringIO
import pandas as pd
import json
import logging
import openai
import os
import warnings
warnings.simplefilter(action='ignore')
#load_dotenv()

OPENAI_API_KEY = os.environ.get("OPENAI_API_KEY")
OPENAI_API_VERSION =os.environ.get("OPENAI_API_VERSION")
OPENAI_API_BASE = os.environ.get("OPENAI_API_BASE") 
EMBED_MODEL = os.environ.get("EMBED_MODEL")
openai.api_type = "azure"
openai.api_version = OPENAI_API_VERSION
openai.api_base = OPENAI_API_BASE 
openai.api_key = OPENAI_API_KEY
#AzureChatOpenAI
os.environ['openai_api_key'] =  OPENAI_API_KEY
os.environ['openai_api_base']= OPENAI_API_BASE
os.environ['openai_api_version'] = OPENAI_API_VERSION
os.environ['openai_api_type'] = "azure"

AZURE_SEARCH_SERVICE_ENDPOINT = os.environ.get("AZURE_SEARCH_SERVICE_ENDPOINT")
AZURE_SEARCH_ADMIN_KEY = os.environ.get("AZURE_SEARCH_ADMIN_KEY")
AZURE_SEARCH_INDEX_NAME = os.environ.get("AZURE_SEARCH_INDEX_NAME")
AZURE_SEARCH_INDEX_NAME_SAFETY = os.environ.get("AZURE_SEARCH_INDEX_NAME_SAFETY")

credential = AzureKeyCredential(AZURE_SEARCH_ADMIN_KEY)
client = SearchClient(endpoint=AZURE_SEARCH_SERVICE_ENDPOINT, 
                      index_name=AZURE_SEARCH_INDEX_NAME_SAFETY, 
                      credential=credential)
                      
SAS = os.getenv("SAS")

os.environ['openai_api_key'] = OPENAI_API_KEY
os.environ['openai_api_base'] = OPENAI_API_BASE
os.environ['openai_api_version'] = OPENAI_API_VERSION
os.environ['openai_api_type'] = "azure"


df = pd.read_csv(SAS)#.iloc[:10000]
columns_mapping = {
    'Division': "Division",
    'INCIDENT_ID': "Incident ID",
    'EtqNumber': "ETQ Number or Etq Number",
    'EventDate': "Event Date",
    'Airline': "Airline",
    'Flight': "Flight",
    'Tail': "Tail Number",
    'Risk': "Risk Level",
    'ReportType': "Report Type",
    'IrropType': "Irregular Operation Type",
    'Cause': "Cause",
    'CauseOther': "Other Cause",
    'Subject': "Subject",
    'Description': "Description",
    'Origin': "Origin Airport",
    'Destination': "Destination Airport",
    'Location': "Location",
    'WSRDate': "WSR Date",
    'OPLEOI': "OPLEOI",
    'AnalystNotes': "Analyst Notes",
    'RiskNotes': "Risk Notes",
    'CreatedDate': "Created Date",
    'Likelihood': "Likelihood",
    'Severity': "Severity",
    'ErrStation': "Error Station",
    'DiscStation': "Discrepancy Station",
    'EventLevel': "Event Level",
    'DAGSRB': "DAGSRB",
    'InvestReq': "Investigation Required",
    'Time': "Time"
}
df.rename(columns=columns_mapping, inplace=True)
df['Event Date'] = pd.to_datetime(df['Event Date'], errors='coerce')
df['Incident ID'] = df['Incident ID'].apply(str)
df['ETQ Number or Etq Number'] = df['ETQ Number or Etq Number'].apply(str)
llm = ChatOpenAI(
model_name='gpt-4',
temperature=0,
openai_api_base=openai.api_base,
openai_api_key=openai.api_key,
model_kwargs={'engine': 'gpt-4'}
)
memory = ConversationBufferMemory(memory_key="chat_history", output_key="output")
PREFIX = '''
If Date or event is mentioned, use "Event Date" column and other relevant ones as required.
Available columns:
Division
Incident ID
ETQ Number or Etq Number
Event Date
Airline
Flight
Tail Number
Risk Level
Report Type
Irregular Operation Type
Cause
Other Cause
Subject
Description
Origin Airport
Destination Airport
Location
WSR Date
OPLEOI
Analyst Notes
Risk Notes
Created Date
Likelihood
Severity
Error Station
Discrepancy Station
Event Level
DAGSRB
Investigation Required
Time

'''
SUFFIX = """
When answering a question, provide detailed insights, 
utilizing all available information.
Include any recommendations and intellectual analyses 
you have at your disposal.   
If Date or event is mentioned, use "Event Date" column and other relevant ones as required.
Available columns:
Division
Incident ID
ETQ Number or Etq Number
Event Date
Airline
Flight
Tail Number
Risk Level
Report Type
Irregular Operation Type
Cause
Other Cause
Subject
Description
Origin Airport
Destination Airport
Location
WSR Date
OPLEOI
Analyst Notes
Risk Notes
Created Date
Likelihood
Severity
Error Station
Discrepancy Station
Event Level
DAGSRB
Investigation Required
Time
The result of `print(df.head())` is as follows:
Input dataframe:
{df}            
Let's begin!
Chat history:
{chat_history}
Question: {question}
Notes:
{agent_scratchpad}"""
def plot_flag(question):   
    plot_prompt = '''Determine if the given question implies a desire for a plot, chart, graph, or visualization.
    Helpful examples:
    
    User: "plot top 10 error stations"
    Assistant: {"plot": "yes","type":"bar"}
       
    User: "top 10 error stations"
    Assistant: {"plot": "no","type":"na"}
    
    User:  'are there any anaomolos in the data?'
    Assistant: {"plot": "no","type":"na"}
        
    User: "show me the trends of incident ids counts"
    Assistant: {"plot": "yes","type":"line"}
    '''       
    total_prompt = plot_prompt + "\nUser: " + question   
    response = openai.ChatCompletion.create(
        engine='gpt-4',
        messages = [
            {"role":"system", "content":"You are an AI assistant that helps people find information."},
            {"role":"user", "content":total_prompt},
        ],
        temperature=0,
        max_tokens=100,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )     
    response = response.choices[0]['message'].content.strip()   
    data = json.loads(response)
    return data

def execute_and_get_output(ai_response, context=None) -> object:
    start_delimiter = "```"
    end_delimiter = "```"
    code_section = ai_response['intermediate_steps'][-1][0].tool_input
    if start_delimiter in code_section and end_delimiter in code_section:
        code_start = code_section.split(start_delimiter)[1]
        extracted_code = code_start.split(end_delimiter)[0]

        code_lines = extracted_code.split('\n')

        last_assignment = None
        last_assignment_index = None

        # Exclude lines starting with "plt"
        filtered_lines = [line for line in code_lines if not line.strip().startswith("plt")]
        filtered_lines = [line for line in  filtered_lines if not line.strip().startswith("python")]
        filtered_lines = [line for line in  filtered_lines if len(line.strip()) !=0]
        filtered_lines = [line.replace('.plot(kind=\'bar\')','') for line in filtered_lines ]
        filtered_lines = [line for line in filtered_lines if not "plot(" in line.strip()]
       
        if len(filtered_lines) == 1:
            try:
                return eval(filtered_lines[0], context)
            except Exception as e:
                return f"Error executing code: {e}"

        for i, line in enumerate(filtered_lines):
            if "=" in line and not line.strip().startswith("#"):
                last_assignment = line.strip()
                last_assignment_index = i

        # Execute the filtered code and get the output
        local_vars = {}
        try:
            exec('\n'.join(filtered_lines), context, local_vars)
            if last_assignment:
                # Extract the variable name from the last assignment
                variable_name = last_assignment.split('=')[0].strip()
                if variable_name in local_vars:
                    return local_vars[variable_name]
            return None
        except Exception as e:
            return f"Error executing code: {e}"
    else:
        try:
            return eval(code_section)
        except:
            return None

def json_output_execute_code(ai_response,df):
    json_output = [{}]
    try:
        execute_code = execute_and_get_output( ai_response, context={'df': df})   
        execute_code_df =pd.DataFrame( execute_code)
        execute_code_df =  execute_code_df.reset_index()
        
        execute_code_df = pd.DataFrame({ execute_code_df.columns[1]:list( execute_code_df[ execute_code_df.columns[0]]),'value':list( execute_code_df[ execute_code_df.columns[1]])})
               
        execute_code_df.rename(columns = {execute_code_df.columns[0]:'name'},inplace=True)
        try:            
            execute_code_df['name'] =  execute_code_df['name'].dt.strftime('%Y-%m-%d')
        except:
            pass
        json_output =  execute_code_df.to_json(orient='records')
        json_output = eval(json_output)
    except Exception as e:
        print(f"An error occurred: {e}")
        
    return json_output 
class CustomePythonAstREPLTool(PythonAstREPLTool):
    """A tool for running python code in a REPL."""
    name = "python_repl_ast"
    description = (
        "Use this tool answer questiones posed to you"
    )
class unrelated_question_tool(BaseTool):
    name = "Un-related-question"
    description = "Use this tool to answer questions not related to safety, airlines incident, incident id, desciption, visualization\
                divisions.\
                Never search online resources here. \
                Just say I do not know."
    
    def _run(self, query):
        return 'I do not know.'

    def _arun(self,query):
        raise NotImplementedError("This tool does not support async")
def create_pandas_dataframe_agent(
    llm: BaseLLM,
    df: Any,
    callback_manager: Optional[BaseCallbackManager] = None,
    prefix: str = PREFIX,
    suffix: str = SUFFIX,
    input_variables: Optional[List[str]] = None,
    verbose: bool = True,
    return_intermediate_steps: bool = True,
    max_iterations: Optional[int] = 15,
    max_execution_time: Optional[float] = None,
    early_stopping_method: str = "force",
    kwargs={},
) -> AgentExecutor:
    """Construct a pandas agent from an LLM and dataframe."""    
    if not isinstance(df, pd.DataFrame):
        raise ValueError(f"Expected pandas object, got {type(df)}")
    if input_variables is None:
        input_variables = ["df", "question", "chat_history","agent_scratchpad"]
    
    tools = [CustomePythonAstREPLTool(locals={"df": df})]+ [unrelated_question_tool()]
    prompt = ZeroShotAgent.create_prompt(
        tools, 
        prefix=PREFIX,
        suffix=SUFFIX, 
        input_variables=["df", "question","chat_history", "agent_scratchpad"]
    )      
    
    partial_prompt = prompt.partial(df=str(df.head()))
    
    llm_chain = LLMChain(
        llm=llm,
        prompt=partial_prompt,
        callback_manager=callback_manager,
    )
    
    tool_names = [tool.name for tool in tools]
        
    agent = ZeroShotAgent(
        llm_chain=llm_chain,
        agent=AgentType.ZERO_SHOT_REACT_DESCRIPTION,
        allowed_tools=tool_names,
        callback_manager=callback_manager,
        **kwargs,
    )
    return AgentExecutor.from_agent_and_tools(
        agent=agent,
        tools=tools,
        verbose=verbose,
        return_intermediate_steps=return_intermediate_steps,
        max_iterations=max_iterations,
        max_execution_time=max_execution_time,
        early_stopping_method=early_stopping_method,
        handle_parsing_errors='Once you have a `Final Answer:` please stop and return it without continuing to solve the query.',
        callback_manager=callback_manager,
        memory=memory
    )

#pdf stuffs
def setup_vector_store(AZURE_SEARCH_SERVICE_ENDPOINT, AZURE_SEARCH_ADMIN_KEY, AZURE_SEARCH_INDEX_NAME,embeddings):    
    return AzureSearch(
        azure_search_endpoint=AZURE_SEARCH_SERVICE_ENDPOINT,
        azure_search_key=AZURE_SEARCH_ADMIN_KEY,
        index_name=AZURE_SEARCH_INDEX_NAME,
        embedding_function=embeddings.embed_query,
    )

def setup_retriever(vector_store, search_type="similarity", k=4):
    return vector_store.as_retriever(search_type=search_type, search_kwargs={"k": k, "include_metadata": True})

def setup_conversational_chain(llm, memory, retriever):
    _template = "Given the following conversation and a follow up question, \
    rephrase the follow up question to be a standalone question.\
    Chat History: {chat_history}\
    Follow Up Input: {question}\
    Standalone question:"
    CONDENSE_QUESTION_PROMPT = PromptTemplate.from_template(_template)
    prompt_template = "Use the following pieces of context to answer the question at the end.\
    If you don't know the answer, just say that I don't know, \
    don't try to make up an answer.\
    {context}\
    Question: {question}\
    Helpful Answer:"
    QA_PROMPT = PromptTemplate(template=prompt_template, input_variables=["context", "question"])
    
    return ConversationalRetrievalChain.from_llm(
        llm=llm,
        memory=memory,
        chain_type="stuff",
        retriever=retriever,
        return_source_documents=False,
        get_chat_history=lambda h: h,
        verbose=False,
        condense_question_prompt=CONDENSE_QUESTION_PROMPT,
        combine_docs_chain_kwargs={'prompt': QA_PROMPT}
    )

def chat_boot(user_id, session_id, question, AZURE_SEARCH_INDEX_NAME, timestamp):
    
    embeddings = OpenAIEmbeddings(
            openai_api_base= openai.api_base,
            openai_api_type='azure',
            deployment="text-embedding-ada-002",
            openai_api_key=openai.api_key,
            chunk_size=1,
        )   
    aag_vector_store = setup_vector_store(AZURE_SEARCH_SERVICE_ENDPOINT, AZURE_SEARCH_ADMIN_KEY,
                                      AZURE_SEARCH_INDEX_NAME, embeddings,)    
     
    aag_retriever = setup_retriever( aag_vector_store)   
    
    llm = AzureOpenAI(
        deployment_name="text-davinci-003",
        model_name="text-davinci-003",
        temperature=0.7,
        openai_api_base=openai.api_base,
        openai_api_key=openai.api_key
    )
    
    #message_history = RedisChatMessageHistory(url="redis://localhost:6379/0", ttl=600, session_id=session_id)
    
    memory = ConversationSummaryBufferMemory(
        llm=llm,
        output_key='answer',
        memory_key='chat_history',
        #chat_memory=message_history,
        return_messages=True
    )
    
    chain = setup_conversational_chain(llm, memory, aag_retriever)
    result = chain({"question": question})
    return result
##CSVs
def enhanced_prompt(question):
    query_prompt = '''

    You are an Azure Cognitive Search expert!
    The data is related to airline safety.
    Your role is to prepare a search query and extract key information.

    Helpful examples:

    Example 1:
    Question: Find pet-related issues.
    search_text: pet,dog,pooch

    Example 2:
    Question: Show me intoxicated passengers and alcohol-related events.
    search_text: intoxicated,alcohol,impaired,drunk

    Your Query:
    Question: {question}
    search_text: <specify_search_text>
    '''
    query_prompt = query_prompt + "\nQuestion: " + question  
    response = openai.ChatCompletion.create(
        engine='gpt-4',
        messages = [
            {"role":"system", "content":"You are an AI assistant that helps people find information."},
            {"role":"user", "content":query_prompt},
        ],
        temperature=0.7,
        max_tokens=500,
        top_p=1,
        frequency_penalty=0,
        presence_penalty=0
    )    
    response = response.choices[0]['message'].content.strip()

    return  response.replace("search_text","")

def retrieve_index(query,top_n):
    
    search_results = client.search(search_text=query,
                                   filter=None,
                                   api_version="2023-07-01-Preview",
                                   top=50)
    df = pd.DataFrame(list(search_results))
    df = df.sort_values(by='@search.score', ascending=False)
    df = df.head(top_n)
    json_data = json.loads(df.to_json(orient='records'))
    return json_data


def similar_incidents(question, top_n):
    top_events = []
    query = enhanced_prompt(question)
    json_data = retrieve_index(query, top_n)    
    for top_event in json_data:
        try:
            top_events.append(top_event['content'])
        except json.JSONDecodeError as e:
            print(f"JSONDecodeError: {e}")
        except Exception as e:
            print(f"An error occurred: {e}")
   
    return top_events
    

def main(req: func.HttpRequest) -> func.HttpResponse:
    logging.info('Python HTTP trigger function processed a request.')
    logging.info(f'Value of OPENAI_API_BASE:  {OPENAI_API_BASE}' )

    try:
        # parse
        req_body = req.get_json()
        user_id = req_body.get("user_id")
        session_id = req_body.get("session_id")
        question = req_body.get("question")
        AZURE_SEARCH_INDEX_NAME = req_body.get("AZURE_SEARCH_INDEX_NAME")
        AZURE_SEARCH_INDEX_NAME_SAFETY = req_body.get("AZURE_SEARCH_INDEX_NAME_SAFETY")
        timestamp = req_body.get("timestamp")
        search_in = req_body.get("search_in")

        if None in [user_id, session_id, question, search_in, AZURE_SEARCH_INDEX_NAME_SAFETY, AZURE_SEARCH_INDEX_NAME, timestamp]:
            return func.HttpResponse(
                "Missing parameters in request body",
                status_code=400
            )
        if  search_in=="manual":        
            result = chat_boot(user_id, session_id, question, AZURE_SEARCH_INDEX_NAME, timestamp)       
            json_result ={
               "user_id": req_body.get("user_id"),
                "session_id": req_body.get("session_id"),
                "question": req_body.get("question"),
                "AZURE_SEARCH_INDEX_NAME": req_body.get("AZURE_SEARCH_INDEX_NAME"),
                "AZURE_SEARCH_INDEX_NAME_SAFETY":req_body.get("AZURE_SEARCH_INDEX_NAME_SAFETY"),
                "timestamp": req_body.get("timestamp"),
                "search_in": req_body.get("search_in"),
                "answer":  result['answer']
                }
        elif search_in=="etq":
            result = similar_incidents(question,top_n=3) 
            json_result ={
               "user_id": req_body.get("user_id"),
                "session_id": req_body.get("session_id"),
                "question": req_body.get("question"),
                "AZURE_SEARCH_INDEX_NAME": req_body.get("AZURE_SEARCH_INDEX_NAME"),
                "AZURE_SEARCH_INDEX_NAME_SAFETY":req_body.get("AZURE_SEARCH_INDEX_NAME_SAFETY"),
                "timestamp": req_body.get("timestamp"),
                "search_in": req_body.get("search_in"),
                "answer":  result
                }
        elif search_in=="etq-agent":
            etq_agent = create_pandas_dataframe_agent(
                llm,
                df,
                callback_manager=None,
                prefix = PREFIX,
                suffix = SUFFIX,
                input_variables = None,
                verbose = True,
                return_intermediate_steps = True,
                max_iterations = 15,
                max_execution_time = None,
                early_stopping_method = "force"
            )
            logging.info( etq_agent)
            result = etq_agent(question)
            plot_status = plot_flag(question)
            answer = result['output']
            json_data = json_output_execute_code(result,df)
            json_result ={
               "user_id": req_body.get("user_id"),
                "session_id": req_body.get("session_id"),
                "question": req_body.get("question"),
                "AZURE_SEARCH_INDEX_NAME": req_body.get("AZURE_SEARCH_INDEX_NAME"),
                "AZURE_SEARCH_INDEX_NAME_SAFETY":req_body.get("AZURE_SEARCH_INDEX_NAME_SAFETY"),
                "timestamp": req_body.get("timestamp"),
                "search_in": req_body.get("search_in"),
                "answer":  answer,
                "plot_status": plot_status,
                "data":  json_data
                }
        else:
            json_result ={
           "user_id": req_body.get("user_id"),
            "session_id": req_body.get("session_id"),
            "question": req_body.get("question"),
            "AZURE_SEARCH_INDEX_NAME": req_body.get("AZURE_SEARCH_INDEX_NAME"),
            "AZURE_SEARCH_INDEX_NAME_SAFETY":req_body.get("AZURE_SEARCH_INDEX_NAME_SAFETY"),
            "timestamp": req_body.get("timestamp"),
            "search_in": req_body.get("search_in"),
            "answer":  "unknown search_in field"
            }
            

        return func.HttpResponse(json.dumps(json_result), mimetype="application/json")

    except Exception as e:
        return func.HttpResponse(
            "An error occurred: {}".format(e),
            status_code=500
        )
