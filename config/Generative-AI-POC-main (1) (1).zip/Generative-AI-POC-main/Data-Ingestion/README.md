# Generative-AI-POC
# Data Ingestion
Data Ingestion code for the Generative AI proof-of-concept app.
