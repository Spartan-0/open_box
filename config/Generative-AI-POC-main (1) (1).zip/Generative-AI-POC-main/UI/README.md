# Generative-AI-POC
# User Interface
UI / UX for the Generative AI proof-of-concept app.
