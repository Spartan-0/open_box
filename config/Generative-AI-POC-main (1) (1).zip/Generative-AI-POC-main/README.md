# Generative-AI-POC
Generative AI proof-of-concept app development.
